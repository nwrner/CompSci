import java.util.Random;

public class LinkedListTwo {
    private ListNode head, current, tail;
    private Random rand = new Random();

    public LinkedListTwo() {
        // System.out.println("LinkedList constructor ...");
        head = null;
        tail = null;
    }

    public int countItems() {
        // System.out.println("Count number of items.");
        int runningCount = 0;
        current = head;

        while (current != null) {
            runningCount++;
            current=current.next;
        }

        return runningCount;
    }

    public void fillList(int alphaNumber, int randomLimit) {
        head = new ListNode();
        head.data = rand.nextInt();
        int runner = 0;

        current = head;
        while (runner != alphaNumber) {
            current.next = new ListNode();
            current.next.data = rand.nextInt(5000);
            current = current.next;
            runner++;
        }
    }

    public long addList() {
        //System.out.print("Add list.")

        long total = 0;
        current = head;
        while (current != tail) {
            total += current.data;
            current = current.next;
        }
        return total;

    }

    public int findItem(int searchTerm) {
        int timesFound = 0;
        current = head;
        while (current != tail) {
            if (current.data == searchTerm) {
                timesFound++;
            }
            current = current.next;
        }
        return timesFound;
    }

    public void doubleList() {
        current = head;
        while (current!=tail) {
            current.data = current.data*2;
            current = current.next;
        }
    }

    public static class ListNode {   // nested class
        // System.out.println("ListNode constructor ...");
        public int data;
        public ListNode next;
        public ListNode() {
        }
    }
}
