/*

o	Program name: ArrayList, Array, LinkedList Experiment
o	Author: J. Gurka & Nick Warner
o	Date: October, 2018
o	Description: This class runs different experiments on ArrayLists, Arrays, and LinkedLists.
o	Input / output: No input, all screen based output.
o	Assumptions and limitations: Assumes no user input, a random number to search for, and the
    values assigned in the constants SIZE, DATA_LIMIT, and SIZE_MULTIPLIER for list sizes.
o	References & resources.  N/A


*/

import java.util.Random;
import java.util.ArrayList;
import java.text.DecimalFormat;


public class ArrayListArrayExercise {

    private int[] array;
    private Random rand;
    private DecimalFormat formatter;
    private long startTime, endTime;
    private ArrayList<Integer> list;
    private final int SIZE = 1_000_000;
    private final int DATA_LIMIT = 5_000;
    private final int SIZE_MULTIPLIER = 40;
    private LinkedListTwo myLinkedList = new LinkedListTwo();
// --------------------


    public ArrayListArrayExercise () {
        list = new ArrayList<Integer>(SIZE);
        array = new int[SIZE];
        rand = new Random();
        formatter = new DecimalFormat();

    }  // ArrayListArrayExercise constructor

// --------------------


    // fillTest method: compare times to fill an ArrayList, a normal array, and a LinkedList.
    public void fillTest() {

        int i, j;

        // Fill ArrayList and time it.
        startTime = (int) System.currentTimeMillis();
        for (i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (j = 0; j < SIZE; j++){
                list.add(rand.nextInt(DATA_LIMIT));
            }
            list.clear();
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Fill test, elapsed time, ArrayList = " + (endTime-startTime) + " milliseconds.");


        // Fill array and time it.
        startTime = (int) System.currentTimeMillis();
        for (i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (j = 0; j < SIZE; j++){
                array[j] = rand.nextInt(DATA_LIMIT);
            }
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Fill test, elapsed time, array = " + (endTime-startTime) + " milliseconds.");


        // Fill LinkedList and time it.
        startTime = (int) System.currentTimeMillis();
        int runner = 0;
        while (runner < SIZE_MULTIPLIER) {
            myLinkedList.fillList(SIZE, DATA_LIMIT);
            runner++;
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Fill test, elapsed time, LinkedList = " + (endTime-startTime) + " milliseconds.");

    }  // fillTest

// --------------------

    // addTest method: compare times to add up an ArrayList, a normal array, and a LinkedList.
    public void addTest() {

        int total;
        int i, j;

        // (re)fill ArrayList
        startTime = (int) System.currentTimeMillis();
        for (i = 0; i < SIZE; i++){
            list.add(rand.nextInt(DATA_LIMIT));
        }

        // sum ArrayList
        total = 0;
        startTime = (int) System.currentTimeMillis();
        for (i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (j = 0; j < SIZE; j++){
                total = total + list.get(j);
            }
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Add test with a total of " + total + ", elapsed time, ArrayList = " + (endTime-startTime) + " milliseconds.");

        // sum array
        total = 0;
        startTime = (int) System.currentTimeMillis();
        for (i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (j = 0; j < SIZE; j++){
                total += array[j];
            }
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Add test with a total of " + total + ", elapsed time, array = " + (endTime-startTime) + " milliseconds.");

        // sum LinkedList
        startTime = (int) System.currentTimeMillis();
        long linkedListTotal = myLinkedList.addList();
        endTime = (int) System.currentTimeMillis();
        System.out.println("Add test with a total of " + linkedListTotal + ", elapsed time, LinkedList= " + (endTime-startTime) + " milliseconds.");

    }  // addTest

// --------------------

    // searchTest method: compare times to fill an ArrayList, a normal array, and a LinkedList.
    public void searchTest() {
        //stub System.out.println(">> stub: in search test");

        int searchTerm = rand.nextInt(DATA_LIMIT);
        int foundOccurances = 0;
        boolean found = false;

        // Loop through the ArrayList and count how many time searchTerm is found.
        startTime = (int) System.currentTimeMillis();
        for (int i = 0; i < list.size(); i++){
           if (list.get(i) == searchTerm) {
               foundOccurances++;
               found = true;
           }
        }

        if (found) {
            endTime = (int) System.currentTimeMillis();
            System.out.println("Item " + searchTerm + " found " + foundOccurances + " times out of a possible " + list.size() + " items. Search test elapsed time, ArrayList= " + (endTime-startTime) + " milliseconds.");
        } else {
            System.out.print("Item " + searchTerm + " not found, ");
            endTime = (int) System.currentTimeMillis();
            System.out.println("search test elapsed time, ArrayList= " + (endTime - startTime) + " milliseconds.");
        }

        foundOccurances = 0; //reset reused variables
        found = false;

        // Loop through the array and count how many time searchTerm is found.
        startTime = (int) System.currentTimeMillis();
        for (int i =0; i < array.length; i++) {
            if (array[i] == searchTerm) {
                found = true;
                foundOccurances++;
                endTime = (int) System.currentTimeMillis();

            }
        }

        if (found) {
            System.out.println("Item " + searchTerm + " found " + foundOccurances + " times out of a possible " + array.length + " items. Search test elapsed time, Array= " + (endTime-startTime) + " milliseconds.");
        } else {
            System.out.print("Item " + searchTerm + " not found, ");
            endTime = (int) System.currentTimeMillis();
            System.out.println("search test elapsed time, array= " + (endTime - startTime) + " milliseconds.");
        }

        // Loop through the LinkedList and count how many time searchTerm is found.
        startTime = (int) System.currentTimeMillis();
        foundOccurances = myLinkedList.findItem(searchTerm);
        endTime = (int) System.currentTimeMillis();
        System.out.println("Item " + searchTerm + " found " + foundOccurances + " times out of a possible " +  myLinkedList.countItems() + " items. Search test elapsed time, LinkedList= " + (endTime-startTime) + " milliseconds.");
    }

// --------------------

    // doubleTest method: compare times to double all values in an ArrayList, a normal array, and a LinkedList.
    public void doubleTest() {
        //stub System.out.println(">> stub: in double test");
        startTime = (int) System.currentTimeMillis();
        for (int i = 0; i < list.size(); i++) {
            list.set(i, list.get(i)*2);
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Double test elapsed time, ArrayList= " + (endTime-startTime) + " milliseconds.");

        startTime = (int) System.currentTimeMillis();
        for (int i =0; i < array.length; i++) {
            array[i] = array[i]*2;
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("Double test elapsed time, array= " + (endTime-startTime) + " milliseconds.");

        startTime = (int) System.currentTimeMillis();
        myLinkedList.doubleList();
        endTime = (int) System.currentTimeMillis();
        System.out.println("Double test elapsed time, LinkedList= " + (endTime-startTime) + " milliseconds.");
    }  // double test

// --------------------

    // Focuses on ArrayLists and compares fill speeds to a List defined at maximum size to one that expands automatically.
    public void ArrayListTester() {

        // Set the ArrayList to size 10 and run it through the loop filling it up.

        ArrayList<Integer> list = new ArrayList<>(10);

        startTime = (int) System.currentTimeMillis();
        for (int i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (int j = 0; j < SIZE; j++){
                list.add(rand.nextInt(DATA_LIMIT));
            }
            list.clear();
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("ArrayList set to 10, elapsed time = " + (endTime-startTime) + " milliseconds.");

        // Set the ArrayList to maximum size and run it through the loop filling it up.
        startTime = (int) System.currentTimeMillis();
        ArrayList<Integer> limitlessList = new ArrayList<>();
        startTime = (int) System.currentTimeMillis();
        for (int i = 1; i <= SIZE_MULTIPLIER; i++) {
            for (int j = 0; j < SIZE; j++){
                limitlessList.add(rand.nextInt(DATA_LIMIT));
            }
            list.clear();
        }
        endTime = (int) System.currentTimeMillis();
        System.out.println("ArrayList set to maximum size, elapsed time = " + (endTime-startTime) + " milliseconds.");
    }

    // tester method: call all tests
    public void tester() {

        System.out.println("\n=========================== Fill Test Results ==============================");
        fillTest();

        System.out.println("\n============================ Add Test Results ========================");
        addTest();

        System.out.println("\n=========================== Search Test Results ===========================");
        searchTest();

        System.out.println("\n========================= Double Test Results =========================");
        doubleTest();

        System.out.println("\n========================= ArrayList Filler Test Results =========================");
        ArrayListTester();

    }  // tester

// --------------------


    // Main method
    public static void main (String args[]) {
        ArrayListArrayExercise timeTest = new ArrayListArrayExercise();
        timeTest.tester();

    }  // main

}  // ArrayListArrayExercise
