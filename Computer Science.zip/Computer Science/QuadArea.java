import java.util.Scanner;
public class QuadArea {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			int x1;
			int y1;
			int x2;
			int y2; 
			int x3;
			int y3;
			int x4;
			int y4;
			double area=0;
			System.out.print("x1: ");
			x1=reader.nextInt(); 
			System.out.print("y1: ");
			y1=reader.nextInt(); 
			System.out.print("x2: ");
			x2=reader.nextInt(); 
			System.out.print("y2: ");
			y2=reader.nextInt(); 
			System.out.print("x3: ");
			x3=reader.nextInt(); 
			System.out.print("y3: ");
			y3=reader.nextInt(); 
			System.out.print("x4: ");
			x4=reader.nextInt(); 
			System.out.print("y4: ");
			y4=reader.nextInt(); 
			area +=(x1*y2)-(x2*y1)+(x2*y3)-(x3*y2)+(x3*y4)-(x4*y3) + (x4*y1) - (x1*y4);
			area = area * 1/2;
			System.out.println(area);
		}
		
}

