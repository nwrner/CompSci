import java.util.Scanner;
public class Savings {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			int GPA;
			int SRA; 
			int IRA; 
			System.out.print("Enter gross pay: ");
			GPA=reader.nextInt(); 
			System.out.print("Enter savings rate: ");
			SRA =reader.nextInt(); 
			System.out.print("Enter IRA rate: ");
			IRA = reader.nextInt();
			System.out.println("Amount to savings: " + (double)(GPA/SRA));
			int a = GPA/SRA;
			System.out.println("Amount to IRA: " + (double)(GPA/SRA)/2); 
			int b = (GPA/SRA)/2; 
			int c = a+b;
			System.out.println("Amount to IRA: " + (double)c); 
		}	
}

