import java.util.Scanner;
public class WeeksOld {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			int userAge;				
			System.out.print("Please enter your age in weeks: ");
			userAge = reader.nextInt(); 
			System.out.println("You are " + userAge/52 + " years old.");
			System.out.println("You are " + userAge*604800 + " seconds old.");
				
		}
		
}

