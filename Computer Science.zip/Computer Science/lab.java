public class lab {
	public static void main (String args[]) {
		
	}
}
