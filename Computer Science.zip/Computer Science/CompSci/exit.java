import java.util.Scanner; 
import java.lang.Math;
import java.math.BigInteger;
public class exit {
	public static void main(String[] args) {
		//Variable defintions
		
		Scanner reader = new Scanner(System.in);		
		Boolean hasGoodCredit; 
		Boolean hasEnoughCredit;
		Boolean hasLowDebt;
		Boolean hasEnoughIncome;
		String customerName; 
		int requestedLoanAmount;
	 	int creditRating;
		int annualIncome;
		int totalDebt;
		System.out.println("This program determines whether or not you qualify for a loan.");
		
		System.out.print("Please enter your name: ");
		customerName = reader.nextLine();		
		System.out.print("Please enter your Requested Loan Amount: ");
		requestedLoanAmount = reader.nextInt();
		System.out.print("Please enter your credit rating: ");
		creditRating = reader.nextInt();
		System.out.print("Please enter your annual income: ");
		annualIncome = reader.nextInt();
		System.out.print("Please enter your total debt: ");
		totalDebt = reader.nextInt();
		hasGoodCredit = creditRating>=700;
		hasEnoughIncome = annualIncome>=75000; 
		hasLowDebt = totalDebt<=10000;
		if (hasGoodCredit && hasEnoughIncome && hasLowDebt) {
			System.out.println("Loan approved, " + customerName);
		} else if (hasLowDebt != true && annualIncome*2>=requestedLoanAmount) {
			System.out.println("Loan approved, " + customerName);		
		} else if (hasEnoughIncome!=true && creditRating >= 750) {
			System.out.println("Loan approved, " + customerName);	
		} else {
			System.out.println("Loan not approved " + customerName);
		}
	}
}
