import java.util.Scanner; 
import java.lang.Math;
import java.math.BigInteger;
public class BigFormula {
	public static void main(String[] args) {
		BigInteger a;
		BigInteger b;
		BigInteger c;
		BigInteger v1;
		BigInteger v2; 
		BigInteger v;
		BigInteger overFlow; 
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		//A variable reader		
		System.out.print("Enter first integer: ");
		a = reader.nextBigInteger();
		System.out.print("Enter second integer: ");
		b = reader.nextBigInteger();
		System.out.print("Enter third integer: ");
		c = reader.nextBigInteger();
		v = c.subtract(a); 
		v = v.multiply(b);
		v = v.add(a);
		//System.out.println(v);
		System.out.println(v);
	}
}
