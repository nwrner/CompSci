import java.util.Scanner; 

//Calculates over time pay for 40+ hours and 50+ hours
//by Nick Warner
//Lab 3.1 


public class LabCh03OvertimePay {
	public static void main(String[] args) {
		int hours;
		int overTime;
		double secondaryOverTime;
		double finalPay; 
		double cache; 
	
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		//A variable reader		
		System.out.print("Hours Worked: ");
		hours = reader.nextInt(); 
		if (hours>40 && hours<=50) {
				overTime = hours - 40;
				finalPay = (overTime * (12.50 * 1.5) + ((hours-overTime)*12.50));
				System.out.println("Pay is " + finalPay);						
		}  else if (hours>50) {
				overTime = 10;
				finalPay = ((10*(12.50*1.5)) + (40*12.50));
				secondaryOverTime = ((hours-50)*(2*12.50));
				System.out.println(finalPay+secondaryOverTime);		
		} else {
				System.out.println("Pay is " + hours*12.50);		
		}
	}
}
