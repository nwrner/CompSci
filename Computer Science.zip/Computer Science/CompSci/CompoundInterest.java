import java.util.Scanner; 
import java.lang.Math;
public class CompoundInterest {
	public static void main(String[] args) {
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		//A variable reader		
		double IR;
		double PR;
		double NP; 
		double result; 

		System.out.print("Enter interest rate: ");
		IR = reader.nextDouble(); 

		System.out.print("Enter principal: ");
		PR = reader.nextDouble();

		System.out.print("Enter number of periods: ");
		NP = reader.nextDouble();

		result = (Math.pow((1 + IR), NP) * PR); 
		
		System.out.print("Amount = ");		
		System.out.println(result);
	}	
}
