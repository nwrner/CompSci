import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class LabCh03Moving extends Basic {

   public static void main(String[] args) {
      LabCh03Moving app = new LabCh03Moving("Lab 2.12", 0, 0, 620, 650);
   }

   // instance variables
   private double x, y;  // (x,y) is location of the player

   public LabCh03Moving( String title, int ulx, int uly, int pw, int ph ) {
      super(title,ulx,uly,pw,ph);
      pads.add( new Sketchpad(10, 40, 600, 600, 0, 100, 0, Color.white ) );

      // start in middle of the pad
      x = 50;
      y = 50;

      super.start();
   }

   public synchronized void step() {
      // activate the first sketchpad (the only one in this app)
      Sketchpad pad = pads.get(0);
      pad.activate();

      // draw the player at (x,y)
      pad.setColor( Color.blue );
      pad.fillRect( x, y, 5, 5 );

   }

   public synchronized void keyPressed(KeyEvent e) {

     int code = e.getKeyCode();
/*
     switch(code) {
	case KeyEvent.VK_LEFT:
		x-=5;
		break;
	case KeyEvent.VK_RIGHT:
		x+=5;
		break;
	case KeyEvent.VK_DOWN:
		y-=5;
		break;
	case KeyEvent.VK_UP:
		y+=5;
		break;
}
*/

if( code == KeyEvent.VK_LEFT  ) {
       		x=x-5;
 	} else if ( code == KeyEvent.VK_RIGHT ) { 
		x+=5;
  	} else if ( code == KeyEvent.VK_DOWN) {
		y-=5;
 	} else {
		y+=5;	
	}


   }// keyPressed

}// LabCh03Moving
