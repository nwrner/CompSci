import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class LabCh04Checkerboard extends Basic {
double x1,x2=0;
   private static double SIZE = 100;

   public static void main(String[] args) {
      LabCh04Checkerboard app = new LabCh04Checkerboard("Lab 4.7", 0, 0, 620, 650);
   }

   // instance variables
   private int number; 
	int breaker = 90; 
   public LabCh04Checkerboard( String title, int ulx, int uly, int pw, int ph ) {
      super(title,ulx,uly,pw,ph);
      pads.add( new Sketchpad(10, 40, 600, 600, 0, SIZE, 0, Color.white ) );

      number = 5;
	
      super.start();
   }

   public synchronized void step() {
      // activate the first sketchpad (the only one in this app)
      Sketchpad pad = pads.get(0);
      pad.activate();
	double spacer = SIZE/number; 
      // put your code below to draw the checkerboard
      // filling the entire pad with number rows and number columns
      // VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
/*
      for (int x=0; x<number+1; x++) { 
	pad.setColor(Color.red);
	pad.fillRect(x1+spacer, 0, spacer, spacer);
	pad.setColor(Color.black);
	pad.fillRect(x1+spacer, spacer, spacer, spacer);
	spacer+=SIZE/number;
	
}
*/

	for (int x = 0; x<number; x++) {
	if (x==0) {
		pad.setColor(Color.red);
		pad.fillRect(x1, x2, spacer, spacer);
	} else {
		double buffer = x2+spacer; 
		pad.setColor(Color.red);
		pad.fillRect(x1, buffer, spacer, spacer);

		pad.setColor(Color.black);
		pad.fillRect(x1, buffer, spacer, spacer);
	
	}
}

	

	

	
//System.out.println( number );


   }// step

   public synchronized void keyPressed(KeyEvent e) {

     int code = e.getKeyCode();

     if( code == KeyEvent.VK_LEFT && number > 2 ) {
        number--;
     }
     else if( code == KeyEvent.VK_RIGHT && number < 50 ) {
        number++;
     }

   }// keyPressed

}// LabCh04Checkerboard
