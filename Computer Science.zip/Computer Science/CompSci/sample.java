import java.util.Scanner; 
import java.lang.Math;
import java.math.BigInteger;

public class sample{
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in); 		
		BigInteger startingBalance = new BigInteger("1000");
		BigInteger deposit = new BigInteger("0");
		System.out.println(startingBalance);
		System.out.println("Please enter the number to deposit: " );
		deposit = reader.nextBigInteger();
		System.out.println(deposit);
		}
}
