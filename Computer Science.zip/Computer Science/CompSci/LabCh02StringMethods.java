import java.util.Scanner; 
import java.lang.Math;

public class LabCh02StringMethods {
	public static void main(String[] args) {
		String fullName;
		String lastName;
		String firstName;
		String number; 
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter name: ");
		fullName = reader.nextLine();
		System.out.print("Enter number: " );
		number = reader.nextLine();	
		lastName =fullName.substring(0, fullName.indexOf(","));
		firstName =fullName.substring( fullName.indexOf(",") + 1, fullName.length());
		System.out.println(lastName + "" + firstName);
		int length = firstName.length() - 1;
		System.out.println(lastName + ": " + lastName.length() + " characters, " + firstName + ": " + length + " characters.");
		System.out.println(number.substring(number.indexOf("(")+1, number.lastIndexOf(")")));
	}
}
