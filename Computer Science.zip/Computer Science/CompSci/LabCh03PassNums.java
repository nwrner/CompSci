import java.util.Scanner; 
import java.lang.Math;
import java.math.BigInteger;
public class LabCh03PassNums {
	public static void main(String[] args) {
		//Variable defintions		
		BigInteger passNum1;
		BigInteger passNum2; 
		BigInteger targetNumber;
		BigInteger product; 
		BigInteger lowerCap =new BigInteger("1");
		targetNumber = new BigInteger("1234567899641975237");
		int zeroResult = 0;
		int compareResult = 0;
		
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		
		//Grabbing user input	
		System.out.print("Enter first pass number: ");
		passNum1 = reader.nextBigInteger();
		System.out.print("Enter second pass number: ");
		passNum2 = reader.nextBigInteger();
		
		//Getting the product of the two user numbers.
		product = passNum1.multiply(passNum2); 
		//Seeing if the value of the first input is 1.
		zeroResult = passNum1.compareTo(lowerCap);
		//Seeing if the the second number is greater than the first.
		compareResult = passNum1.compareTo(passNum2);
		
		//Checking the upper two to allow or deny access
		if (product.equals(targetNumber) && zeroResult!=0 && compareResult==-1) {
			System.out.println("Access granted.");		
		} else {
			System.out.println("Access denied.");
		}
	}
}
