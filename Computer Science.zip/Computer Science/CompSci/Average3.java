import java.util.Scanner; 
import java.lang.Math;

public class Average3 {
	public static void main(String[] args) {
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		//A variable reader		
		System.out.print("Enter first integer: ");
		Integer a = reader.nextInt(); 
		System.out.print("Enter second integer: ");
		Integer b = reader.nextInt();
		System.out.print("Enter third integer: ");
		Integer c = reader.nextInt();
		System.out.println("Average is " + (double)(a + b + c ) / 3);	
	}
}
