import java.lang.Math;
public class lab {
	public static void main (String args[]) {
		double x,y,d;
		x = 3;
		y = 4;
		d=Math.sqrt((Math.pow(x,2)+Math.pow(y,2))); 
		System.out.println(d);
	}
}

