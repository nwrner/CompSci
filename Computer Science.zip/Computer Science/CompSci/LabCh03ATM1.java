import java.util.Scanner; 
import java.lang.Math;
import java.math.BigInteger;

public class LabCh03ATM1 {
	public static void main(String[] args) {
		int startingBalance = 1000;
		int PIN = 3891;
		int enteredPin; 
		int userChoice;
		double deposit;
		double withdraw;
		//Create the scanner object
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter PIN: ");
		enteredPin = reader.nextInt();
		//If the user's entered pin matches the actual pin
		if ( enteredPin == PIN ) {
			System.out.println("1. deposit");
			System.out.println("2. withdraw");
			System.out.println("3. inquiry");
			System.out.println("========");
			System.out.print("Please enter your choice: ");
			userChoice = reader.nextInt();
			//If they chose to deposit
			if ( userChoice == 1 )  {
				System.out.print("Please enter amount to deposit: ");		
				deposit = reader.nextDouble(); 
				//If the amount they want to deposit is negative
				if ( deposit < 1)  {
					System.out.println("Cannot deposit non-positive value.");
					System.exit(0);
				} 
				//If the amount they want to depositi is positive
				else {
					startingBalance+=deposit; 
					//startingBalance = startingBalance + deposit = startingBalance+=deposit; 
					System.out.println("New balance: " + startingBalance);				
				}		

			} 
			//If the user chose to withdraw 
			else if ( userChoice == 2 ) {
				System.out.print("Please enter amount to withdraw: ");
				withdraw = reader.nextDouble();
				//If the amount they want to withdraw is negative 
				if ( withdraw < 1 ) { 
					System.out.println("Cannot withdraw negative amount.");				
				} 
				//If the amount they want to withdraw is not a multiple of 20
				else if ( withdraw % 20 != 0 ) {
					System.out.println("Cannot withdraw non-multiples of 20.");				
				} 
				//If the amount they want to withdraw is more than the amount they have in their account
				else if ( withdraw > startingBalance ) {
					System.out.println("Cannot withdraw more than current balance.");					
				} 
				//If the amount they want to withdraw is not negative, is a multiple of 20, and is less than the amount they have in their account. 
				else {
					startingBalance-=withdraw;
					System.out.println("New balance: " + startingBalance);	
				}	
		
			} 
			//If the user chooses to inquiry their account 
			else if ( userChoice == 3 ) {
				//Return their balance
				System.out.println("Your balance: " + startingBalance);			
			} 
			//If the user did not choose 1, 2, or 3 
			else {
				System.out.println("No valid input detected. Exiting.");			
			}					
		} 
		//If the pin does not match
		else {
			System.out.println("a rude message");
		}
	}
}
