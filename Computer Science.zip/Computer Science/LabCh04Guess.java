import java.util.Scanner;
import java.util.Random;

//Nick Warner
// Lab 4.2
// February 12, 2018 


public class LabCh04Guess {
  
   public static void main(String[] args) {

      Scanner keys = new Scanner(System.in);

      Random rng = new Random();
      int secret = rng.nextInt(100)+1;
      int userGuess = 110;
      while (userGuess != secret) {
	      System.out.print("Enter your guess "); 
	      userGuess = keys.nextInt();
	      if (userGuess > secret) {
			System.out.println("Too high.");
	      } else if ( userGuess < secret) {
			System.out.println("Too low");
		} else if ( userGuess == secret) {	
			System.out.println("Correct!");
			System.exit(0);
		}
	      //System.out.println("TESTING ONLY---secret number is " + secret );
      }     
   }// main

}// LabCh04Guess
