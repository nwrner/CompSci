import java.util.Scanner;

/* Nick Warner
Lab Chapter 4, Stars
Grabs user input as a limit number and prints that many *
*/


public class LabCh04Stars {
		public static void main (String[] args) {
			//Define scanner
			Scanner reader = new Scanner(System.in);  
			//Define the limit				
			int limit;
			//Ask the user for the limit and assign it
			System.out.print("Enter # of lines: ");
			limit = reader.nextInt();
			//Define the star variable 			
			String star = "*";
			
			//Loop through amount of time user specified, printing as you go.
			for (int x = 0; x <limit; x++) {
				System.out.print(star);				
				star += "*";
				System.out.println("");
			}
			
	}
		
}

