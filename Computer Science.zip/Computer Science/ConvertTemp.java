import java.util.Scanner;
public class ConvertTemp {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			System.out.print("Enter a temperature in Fahrenheit: ");
			double userTemp = reader.nextDouble(); 
			userTemp = (double)(userTemp-32)*5/9; 
			System.out.println("Your temperature in Celsius: " + userTemp);
		}
		
}

