/** File: LabCh09FileIOLab1.java
    
    ### Complete
    Name: Nick Warner
    Section: CS 1050 
    Lab #: 9.1
    
	 Read a file of strings, prepend your name and output the new string to
    an output file
	 
	 Input	File LabCh09FileIO_Input1.txt that has a string to echo
    	 
	 Process	Read the string, prepend your name
	 
	 Output	A file with lines for the name and original string
            The output file is named LabCh09FileIO_Output1.txt
            
    Note 	Without your added code, the program will enter an infinite loop.
            (Why?)
*/

import java.util.Scanner;  // Access the Scanner class
import java.io.*;          // Access PrintWriter and related classes

public class LabCh09FileIOLab1 {

   public static void main(String[] args) throws IOException {
   
      // Declare variables
  
      final String INPUT_FILE  = "LabCh09FileIO_Input1.txt";
      final String OUTPUT_FILE = "LabCh09FileIO_Output1.txt";
      
      String inputLine = "";     // Input line read from the file
      String name = "Jane";      // Name to prepend
      String outputLine = "";    // The string with name + inputLine
   	
   	// Access the input/output files
      
      Scanner input  = new Scanner(new File(INPUT_FILE));
      PrintWriter output = new PrintWriter(new FileWriter(OUTPUT_FILE));
      
      // Begin program execution
      
      System.out.println("Reading  file " + INPUT_FILE  + "\r\n" +
                         "Creating file " + OUTPUT_FILE + "\r\n");
   	
   	// Read the input file's individual lines. 
   	
      while (input.hasNext()) {
     		//### Add code here to:
            // 1. Read the next line
            // 2. Prepend your name to form an output line
            // 3. Write the output line to the output file
	    String next = input.nextLine();
	    output.println("Nick " + next);
      } // End while

      /* ### Add code here to   
   	   1. Close the input file
   	   2. Close the output file
      */
      output.close();
      input.close();
      return;	
   } // End main
} // End class
