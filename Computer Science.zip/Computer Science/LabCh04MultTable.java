import java.util.Scanner;
public class LabCh04MultTable {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			int limit;
			System.out.print("Enter limit: ");
			limit = reader.nextInt();
			System.out.print("  ");
			for (int z = 1; z <=limit; z++) {
				System.out.printf("%4d", z);
			}
			System.out.println("");
			System.out.println("");
			for (int y = 1; y <=limit; y++) {
				System.out.print(y + " ");
				for (int x = 1; x <= limit; x++) {					
					System.out.printf("%4d", x*y);
				
			}
			System.out.println("");	
		}
			
	}
		
}

