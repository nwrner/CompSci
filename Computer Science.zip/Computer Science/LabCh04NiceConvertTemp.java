import java.util.Scanner;
public class LabCh04NiceConvertTemp {
		//Nick Warner
		//Lab 4.1
		//February 12, 2017
		//Looping prompt for F to C converter. 
 
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in); 
			boolean done = false;
			String userBreak;
			char cache;

			while (done==false) {
				//Ask for input in F, change it to C, and print it out. 			
				System.out.print("Enter a temperature in Fahrenheit: ");
				double userTemp = reader.nextDouble(); 
				userTemp = (double)(userTemp-32)*5/9;
				System.out.println("Your temperature in Celsius: " + userTemp);

				//Prompt to continue 				
				System.out.print("Continue?: ");
				userBreak = reader.next();
				//Get the first letter of the answer. 
				cache = userBreak.charAt(0);
				//Make it lowercase. 
				cache = Character.toLowerCase(cache);
				//Break if their answer is not yes. 
				if (cache!='y') {
					done=true;
			}	
		}		
	}
}

