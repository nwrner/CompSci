//Lab 5 ; High Temperature
//Nick Warner
//Febraury 26, 2018 

import java.util.Scanner;  
import java.io.*;         

 
public class LabCh05HighTemps {

   public static void main(String[] args) throws IOException {
	//Defining the name of the file the user wants to use. 	
	Scanner reader = new Scanner(System.in);
	System.out.print("File name?: ");
	String INPUT_FILE  = reader.nextLine();

	//Defining the name of the output file. 
	final String OUTPUT_FILE = "output.txt";
      
	
	int count = 0; 						//Count of numbers in the input file. 
	int abCount = 0; 					// Count of numbers above the average. 
	int ceiling = 0; 					//Acting as the upper limit, similar to a for loop, without the for loop. 
	int secondCeiling = 0;  				//Acting as the upper limit, similar to a for loop, without the for loop.
	int smallest = Integer.MAX_VALUE; 	//Setting a guaranteed smaller number. 
	int biggest = Integer.MIN_VALUE; 		//Setting a guaranteed larger number. 

	//Variable double definitions. 
	double average=0; 					//The average of all numbers. 
	double backCurve = 0; 				//The average of all above average numbers.      

	
   	try { 
		//Define the scanners (in and out) 
      		Scanner input  = new Scanner(new File(INPUT_FILE));
		PrintWriter output = new PrintWriter(new FileWriter(OUTPUT_FILE));

		//While the input file still has content, increase the count of the numbers found there and add them to the total 			number of their sums. For example, if the document contians "2, 3, and 4", average will be 9, and count will be 3. 
		while (input.hasNext()) {
			count++;
			average+=Integer.valueOf(input.next());
			
			
			
		}
		
		//Define myIntArray as a new array with the number of numbers found in the file (AKA 'count'), and close the 
		//instance of the file, essentially resetting the cursor. Finally assign the number of average. 
		int[] myIntArray = new int[count];
		input.close();
		average = average/count;
		input  = new Scanner(new File(INPUT_FILE));
		
		//While there are still ines in the file, count from the numbers 0 to the number of items in myIntArray. Next, 
		//assign the items in the file to those numbers. f they are greater than the average number, increase the number of 
		//the above average numbers. 
		while (input.hasNext()) {
			for (int i = 0; i  < myIntArray.length; i++) {
				myIntArray[i]=Integer.valueOf(input.next());
				if (myIntArray[i]>average) {			
					abCount++; 
				}
			}

			//Define the above average list as the number of  above average items. Then, for the number of items 0 and the 				length of myIntArray, if that number index it is above average, add it to the index "ceiling", with that value., then 				increase the ceiling. 
			int[] abAverage = new int[abCount]; 

			for (int i = 0; i  < myIntArray.length; i++) {
				if (myIntArray[i]>average) {
					abAverage[ceiling]=myIntArray[i];
					ceiling++;
				}
			}

			//Writing the number of above average numbers to the file. //For numbers 0 to the number of the above average 				numbers, print them. If that number is smaller than the biggest number Java can hold (for the first loop) and if 			it's smaller than that variable redefined, it is not the smallest. Then, if that number is bigger than the smallest 				number Java can hold (for the first loop) and if it's bigger than that variable redefined., it is now the biggest. 				Then, increase the number of the second ceiling, and backCurve is then summed on itself. 
			output.println("Here are the " + abCount + " above average temps: ");

			
			for (int i = 0; i < abAverage.length; i++) {
				output.println(abAverage[i]);
					if (smallest > abAverage[i]) {
		        			smallest = abAverage[i];
		   			 } 
					if (biggest < abAverage[i]) {
		        			biggest = abAverage[i];
		   			 }
				secondCeiling++; 
				backCurve+=abAverage[i];
				}
			}
		
		//backCurve is then defined as the average of those numbers.
		backCurve=backCurve/secondCeiling;
	  	
		
		//Writie to the file and then close it. 
		output.println("Average = " + backCurve);
		output.println("Min = " + smallest);
		output.println("Max = " + biggest);
		output.close();

		//Display success to console.
		System.out.println("Calculations complete, writing to " + OUTPUT_FILE);
	}
	
	//...catch any errors and output the error message of an invalid file name. (continued from line 33).
	catch (FileNotFoundException exception) {
		System.out.println("!!!!!!!----Invalid file name----!!!!!!");
		System.out.println("Calculations incomplete. Cancelled due to invalid file name.");
	}

     
     
      return;	
   } 
} 
