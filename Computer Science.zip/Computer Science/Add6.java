import java.util.Scanner;
public class Add6 {
		public static void main (String[] args) {
			Scanner reader = new Scanner(System.in);  
			int input;
			int sum=0;

			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("enter a number: ");
			input=reader.nextInt(); 
			sum+=input;
			System.out.print("total=" + Integer.toString(sum)); 
		}
		
}

