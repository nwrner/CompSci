

import java.util.Arrays;
import java.util.Scanner;
import java.io.*;

public class LabCh05SumSubRect {
    public static void main(String[] args) {
        try {
            Scanner input = new Scanner(new File("/Users/Nick/IdeaProjects/Test/src/com/example/Data5-4"));
            int numRows = input.nextInt();
            int numColumns = input.nextInt();



            double[][] data = new double[numRows][numColumns];


            //System.out.println(Arrays.toString(data));

            Scanner reader = new Scanner(System.in);

            System.out.print("Please enter your first row: ");
            int firstRow = reader.nextInt();
            System.out.print("Please enter your second row: ");
            int lastRow = reader.nextInt();
            System.out.print("Please enter your first column: ");
            int firstColumn = reader.nextInt();
            System.out.print("Please enter your second column: ");
            int lastColumn = reader.nextInt();



            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < numColumns; j++) {
                    data[i][j]=Double.valueOf(input.next());
                }
            }
            double lineTotal=0;


            for (int i = 0; i <= lastColumn; i++) {
                System.out.println(data[firstRow][i]);
                lineTotal+=data[firstRow][i];
            }
            System.out.println("");
            for (int i = 0; i <= lastColumn; i++) {
                System.out.println(data[lastRow][i]);
                lineTotal+=data[lastRow][i];
            }

            System.out.println("");
            for (int i = 0; i <= lastRow; i++) {
                System.out.println(data[i][lastColumn]);
                lineTotal+=data[i][lastColumn];
            }
            System.out.println("");
            for (int i = 0; i <= lastRow; i++) {
                System.out.println(data[i][firstColumn]);
                lineTotal+=data[i][firstColumn];
            }

            System.out.println(lineTotal);

        } catch (FileNotFoundException exception) {
            System.out.println("Unable to open file.");
        }

    }
}