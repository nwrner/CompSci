/*
Nick Warner
Core Lab 6.1
 */


import java.util.Scanner;


public class LabCh06TempConvert {

    public static void main(String[] args) {
        Scanner keys = new Scanner(System.in);
        double temp;

        System.out.print("Enter a temp in Fahrenheit: ");
        temp = keys.nextDouble();
        System.out.println("That temp in centigrade is " + convertFahrToCent(temp));

        System.out.print("Enter a temp in centigrade: ");
        temp = keys.nextDouble();
        System.out.println("That temp in Fahrenheit is " + convertCentToFahr(temp));

    }// main

    // **************************
    // add your two methods here:
    // **************************

    //Returns F to C.
    public static double convertFahrToCent(double temp) {
        return((temp-32)*5/9);
    }

    //Returns C to F.
    public static double convertCentToFahr(double temp) {
        return( (temp*9/5) + 32 );
    }


}
