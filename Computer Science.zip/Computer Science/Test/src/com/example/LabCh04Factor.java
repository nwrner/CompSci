package com.example;

import java.util.Scanner;
import java.util.Random;
import java.lang.Math;
//Nick Warner
// Lab 4.2
// February 12, 2018 


public class LabCh04Factor {
  
   public static void main(String[] args) {
	//Variable defintions 
	int userNumber; 
	int attempt=3; 
	int cache = 0;
	
	//Scanner defintion
	Scanner reader = new Scanner(System.in);
	//Getting user's number.
	System.out.print("Please enter your number: ");
	userNumber = reader.nextInt();
	//While the factors squared are less than the user''s number and is greater than 3. 	
	while ( (Math.pow(attempt, 2) < userNumber + 50) && (Math.pow(attempt, 2) > 3)) {
		//If it is divided evenly 
		if ( userNumber % attempt==0) {	
			//Then it is a factor
			System.out.println(attempt + " is a factor.");
			System.exit(0);
		//Otherwise		
		} else {	
			//Print out the failed factor with it's remainder. 
			System.out.println(attempt + " has remainder " + userNumber % attempt + " so not a factor.");
			//Assign that number to cache. 
			cache = attempt;
		}
		//Increase the cache number.
		attempt+=2;	
	}
	//If cache (the most recent factored number) is greater than the userNumber:
	if ( (Math.pow(cache+1,2)) > userNumber ) {
		//Print out that it is a prime number.
		System.out.println(userNumber + " is prime.");
	}
     	
   }// main

}// LabCh04Guess
