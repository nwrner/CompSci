/** File: LabCh09FileIOLab2.java
    
    ### Complete
    Name: Nick Warner
    Section: CS 1050
    Lab #: 9.2
    
	 Read a file with individual lines that have last name, first name and a
    phone number. Output the first name, last name and the area code.
    
    This program builds on an earier lab
    	 
	 Input	File LabCh09FileIO_Input2.txt that has the data. The first line
            of the file contains the number of data lines that follow
    	 
	 Process	Read the lines and rearrange the name and extract the area code
	 
	 Output	A file with lines for the name and area code
            The output file is named LabCh09FileIO_Output2.txt
            
    Note 	Without your added code, the program will enter an infinite loop.
            (Why?)
*/
//package com.example;
import java.util.Scanner;  // Access the Scanner class
import java.io.*;          // Access PrintWriter and related classes
import java.util.Arrays;

public class LabCh09FileIOLab2 {

   public static void main(String[] args) throws IOException {
   
      // Declare variables
      String fullName, areaCode, fullNum, firstName, lastName = ""; 
      
      final String INPUT_FILE  = "/Users/Nick/IdeaProjects/Test/src/com/example/LabCh09FileIO_Input2.txt";
      final String OUTPUT_FILE = "LabCh09FileIO_Output2.txt";
      Scanner keys = new Scanner( System.in );
      int lineCount = 0;
       // ### Declare your variables here. Hint: use the names from the earlier
      // ### lab

   	// Access the input/output files




      Scanner input  = new Scanner(new File(INPUT_FILE));
      PrintWriter output = new PrintWriter(new FileWriter(OUTPUT_FILE));

       int numLines = input.nextInt();
       numLines++;

      while (input.hasNextLine()) {
          System.out.print(input.nextLine() + " ");
      }

       input  = new Scanner(new File(INPUT_FILE));

      int numIts = 0;
      String[][] contents = new String[numLines][];




      while (numIts < numLines) {
        contents[numIts] = input.nextLine().split(" ");
        numIts++;
      }
       output.println((numLines-1) + " people:");

       for (int i = 1; i < numLines; i++) {
          for (int j = 0; j < numLines-1; j++) {

              //System.out.println(contents[i][j]);
              if (contents[i][j].charAt(0) == '(') {
                  output.println(contents[i][1] + " " + contents[i][0].substring(0, contents[i][0].length()-1) + " " +
                          contents[i][j].substring(1,4)+ " ");
              }
          }
      }

    //System.out.println(Arrays.toString(contents[1]));


        output.close();
       input.close();

      return;	
   } // End main
} // End class
