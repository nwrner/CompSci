
/*
    Nick Warner
    Lab 6.3

    This program makes a multiplexor method using a method.
 */

package com.example;
public class LabCh06Mux {

   public static void main(String[] args) {

      // test all rows of truth table for mux:
      for (int s=0; s<=1; s++) {
         for (int a=0; a<=1; a++) {
            for (int b=0; b<=1; b++) {
               System.out.println(s+ " " + a + " " + b + " " + mux(s,a,b) );
            }
         }
      }

   }// main

   // ************************************
   // write your methods and, or, not, mux
   // below:
   // ************************************



    private static int mux (int s, int a, int b) {
       if (s==0) {
           return a;
       } else if (s==1) {
           return b;
       }
       return 0;
    }


}
