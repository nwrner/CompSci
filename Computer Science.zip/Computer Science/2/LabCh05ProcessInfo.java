/** File: LabCh09FileIOLab2.java
    
    ### Complete
    Name: Nick Warner
    Section: CS 1050
    Lab #: 9.2
    
	 Read a file with individual lines that have last name, first name and a
    phone number. Output the first name, last name and the area code.
    
    This program builds on an earier lab
    	 
	 Input	File LabCh09FileIO_Input2.txt that has the data. The first line
            of the file contains the number of data lines that follow
    	 
	 Process	Read the lines and rearrange the name and extract the area code
	 
	 Output	A file with lines for the name and area code
            The output file is named LabCh09FileIO_Output2.txt
            
    Note 	Without your added code, the program will enter an infinite loop.
            (Why?)
*/

import java.util.Scanner;  // Access the Scanner class
import java.io.*;          // Access PrintWriter and related classes

public class LabCh05ProcessInfo {

   public static void main(String[] args) throws IOException {
   
      // Declare variables
      String fullName, areaCode, fullNum, firstName, lastName = ""; 
      
      final String INPUT_FILE  = "LabCh09FileIO_Input2.txt";
      final String OUTPUT_FILE = "LabCh09FileIO_Output2.txt";
      
      int nLines = 0;      // # of lines to read
	
      // ### Declare your variables here. Hint: use the names from the earlier
      // ### lab
         	
   	// Access the input/output files
      
      Scanner input  = new Scanner(new File(INPUT_FILE));
      PrintWriter output = new PrintWriter(new FileWriter(OUTPUT_FILE));
      
      // Begin program execution
      

      System.out.println("Reading  file " + INPUT_FILE  + "\r\n" +
                         "Creating file " + OUTPUT_FILE + "\r\n");
   	
      // ### Add code here to get the number of data lines. Call it nLines
      
   	// Read the input file's individual lines. 
   	int numPeople = input.nextInt();
	output.println(numPeople + " people:");
	nLines = numPeople;
      //while (input.hasNext()) {
	 for (int i = 1; i <= nLines && input.hasNext(); i++) {		
		
      } // End for

      /* ### Add code here to   
   	   1. Close the input file
   	   2. Close the output file
      */
      output.close(); 
      input.close();
      return;	
   } // End main
} // End class
