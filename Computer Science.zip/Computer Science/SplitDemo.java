import java.util.Scanner;

public class SplitDemo {

   public static void main(String[] args) {
      Scanner keys = new Scanner( System.in );
      String data;  // holds the string to be split
      String[] tokens;  // holds the individual "words" in data

      System.out.print("Enter test string: ");
      data = keys.nextLine();

      // split data into tokens separated by spaces
      tokens = data.split("[ ]");

      // display the tokens one per line
      for(int k=0; k<tokens.length; k++ ) {
         System.out.println(k + ":   <" + tokens[k] + ">");
      }
      
   }

}
